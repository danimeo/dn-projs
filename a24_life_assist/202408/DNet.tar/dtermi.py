import itertools
import json
import os
import re
import importlib
from threading import Thread, Lock
import time

# regex_1 = re.compile(r'\\033\[[0-9;]+[A-Za-z]')

lock = Lock()


def displayable_str(_str: str, **values):
    _str = _str.format(**values)
    _str = _str.encode('unicode_escape').replace(b'\\\\', b'\\').decode("unicode_escape")
    return _str


def clear():
    print('\033[2J', end='')

from itertools import zip_longest
from rich.console import Console
from rich.columns import Columns
from rich.text import Text
from rich.table import Table



class DT:
    def __init__(self, dt_filename):
        with open(dt_filename, 'r', encoding='utf-8') as file:
            self.conf = json.load(file)
        
        self.module: importlib.ModuleType = None
        self.updating = False
        self.updating_thread: Thread = None

        self.console = Console()


        
    def clear_content(self):
        print('\033[{};{}H\033[K\033[1B'.format(1 + self.conf['head']['top'] + self.conf['head']['height']
                                                  + self.conf['main_view']['top'], 
                                                1 + self.conf['head']['left']),
            sep='', end='', flush=True
        )
        

    def print_head(self, head=None):
        
        # print('\033[s', end='')

        if head is not None and isinstance(head, str):
            print(
                # Head
                '\033[{};{}H'.format(1 + self.conf["head"]["top"], 
                                     1 + self.conf["head"]["left"]),
                displayable_str(head, **self.conf),
                sep='', end='', flush=True
            )

        # print('\033[u', end='')
        
    def print_prompt(self, initializing=False):

        # print('\033[s', end='')

        # print(
        #     '\033[K\033[1B' * (self.conf['mod']['height'] - list(content).count('\n') + 1), 
        #     sep='', end='', flush=True
        # )
        print(
            # Prompt
            '\033[K\033[1B',
            # '\033[s' if first_time else '\033[u',

            '\033[{};{}H'.format(1 + self.conf["head"]["top"] + self.conf['head']['height']
                                   + self.conf['main_view']['top'] + self.conf['main_view']['height']
                                   + self.conf['prompt']['top'], 
                                 1 + self.conf['prompt']['left']),
            self.conf['prompt']['content'], 
            '\033[0K',
            '\033[s',
            # '\033[s' if initializing else '\033[u', 
            sep='', end='', flush=True
        )
        # print('\033[s', end='')

        
    def update(self, content=''):
        print('\033[s', end='')

        self.clear_content()
        
        if self.module is not None:
            # print(
            #     '\033[{};{}H'.format(1 + self.conf["head"]["top"] + self.conf['head']['height']
            #                           + self.conf['main_view']['top'],
            #                      1 + self.conf['main_view']['left']),
            #     # Content
            #     displayable_str(content, **self.module.conf),
            #     '\033[{};{}H'.format(1 + self.conf["head"]["top"] + self.conf['head']['height']
            #                           + self.conf['main_view']['top'] + self.conf['main_view']['height'],
            #                           + self.conf['prompt']['top'],
            #                      1 + self.conf['main_view']['left']),
            #     '\033[u',
            #     sep='', end='', flush=True
            # )

            

            
            table_1 = Table(title="[bold]:page_facing_up: 列表[/bold]", title_justify='left', title_style='bold', show_header=False, expand=True, show_edge=False)
            # [table.add_column(justify="left") for i in range(self.module.conf["list_view_n_cols"])]

            table_2 = Table(title="[bold]:zap: 记录[/bold]", title_justify='left', title_style='bold', show_header=False, expand=True, show_edge=False)
            # [table.add_column(justify="left") for i in range(self.module.conf["list_view_n_cols"])]
            # table_2.row_styles()

            # del self.table.rows[1:]
            lst_1 = list(zip_longest(*[iter(self.module.conf["list_view_content"])] * self.module.conf["list_view_n_rows"], fillvalue=' '))
            if lst_1:
                lst_1[-1] += (' ',) * (len(lst_1[0]) - len(lst_1[-1]))
                [table_1.add_row(*s, style="white") for s in zip(*lst_1)]

            # del self.table_2.rows[1:]
            lst_2 = list(zip_longest(*[iter(self.module.conf["log_view_content"])] * self.module.conf["log_view_n_rows"], fillvalue=' '))
            if lst_2:
                lst_2[-1] += (' ',) * (len(lst_2[0]) - len(lst_2[-1]))
                [table_2.add_row(*s, style="white") for s in zip(*lst_2)]


            # table.add_row("1", "Buy Milk", "✅")
            # table.add_row("2", "Buy Bread", "✅")
            # table.add_row("3", "Buy Jam", "❌")
            

            print(
                '\033[{};{}H'.format(1 + self.conf["head"]["top"] + self.conf['head']['height']
                                      + self.conf['main_view']['top'],
                                 1 + self.conf['main_view']['left']),
                sep='', end='', flush=True)
            
            # print(
            #     displayable_str(content, **self.module.conf),
            #     sep='', end='', flush=True)
            self.console.print(content, end='')

            self.console.print(table_1)
            print('\n', sep="", end="", flush=True)
            self.console.print(table_2)

            
            print(
                '\033[{};{}H'.format(1 + self.conf["head"]["top"] + self.conf['head']['height']
                                      + self.conf['main_view']['top'] + self.conf['main_view']['height'],
                                      + self.conf['prompt']['top'],
                                 1 + self.conf['main_view']['left']),
                '\033[u',
                sep='', end='', flush=True)
            # print(lst_2)


    def load_mod(self, mod_filename=''):
        if not mod_filename:
            mod_filename = self.conf['mod']['path']
        mod_filename = os.path.basename(mod_filename).replace('.py', '')
        self.module = importlib.import_module('mod.' + mod_filename)


    def mod_loop(self, **args):
        while self.updating:
            self.module.__callback__(**args)

            self.update(content=self.module.conf["content"])
            # print('\033[u', end='')
            
            # self.print_prompt()

            time.sleep(self.conf["updating_interval_seconds"])


    def mainloop(self):

        # print('\033[1B', end='')
        clear()
        self.print_head(self.conf["welcome"])
        self.print_prompt(initializing=True)

        self.updating_thread = Thread(target=self.mod_loop)
        self.updating = True
        self.updating_thread.start()

        while True:
            # self.print_prompt(initializing=True)

            cmd = input()

            if cmd in (':q', ':Q', 'exit', 'quit'):
                clear()
                print('\033[1;1H')
                self.updating = False
                exit()
            else:
                self.module.__handle__(cmd)

            self.update(content=self.module.conf["content"])
            self.print_prompt()


def create_DT(dt_filename, mod_filename=''):
    dt = DT(dt_filename)
    dt.load_mod(mod_filename)
    dt.mainloop()


if __name__ == '__main__':
    create_DT('conf/snote.dt.json', mod_filename='med_logger')

